conda create -n facial python=3.10 -y

conda activate facial

pip install ultralytics
